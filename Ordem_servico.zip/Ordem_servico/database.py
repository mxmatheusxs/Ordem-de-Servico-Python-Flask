import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

# Função para inicializar o banco de dados
def init_db():
    conn = sqlite3.connect('work_orders.db')
    c = conn.cursor()
    
    # Tabela de ordens de serviço
    c.execute('''
        CREATE TABLE IF NOT EXISTS work_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client TEXT NOT NULL,
            date TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT NOT NULL,
            description TEXT,
            image BLOB,
            copied INTEGER DEFAULT 0  -- Campo para indicar se foi copiado
        )
    ''')
    
    # Tabela de usuários
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )
    ''')
    
    # Verificar se o usuário padrão já existe
    email = "admin@admin.com"
    password = "Admin@2025"
    password_hash = generate_password_hash(password)
    
    c.execute("SELECT * FROM users WHERE email = ?", (email,))
    user = c.fetchone()
    
    # Se o usuário não existir, criá-lo
    if not user:
        c.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, password_hash))
        print(f"Usuário padrão criado: {email}")
    else:
        print(f"Usuário padrão já existe: {email}")
    
    conn.commit()
    conn.close()

# Função para adicionar um novo usuário (opcional, caso precise adicionar mais usuários)
def add_user(email, password):
    password_hash = generate_password_hash(password)
    with sqlite3.connect('work_orders.db') as conn:
        c = conn.cursor()
        c.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, password_hash))
        conn.commit()

# Função para buscar usuário por e-mail
def get_user_by_email(email):
    with sqlite3.connect('work_orders.db') as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE email = ?", (email,))
        return c.fetchone()

# Funções de manipulação de ordens de serviço
def insert_work_order(client, date, start_time, end_time, description, image_blob=None):
    with sqlite3.connect('work_orders.db') as conn:
        c = conn.cursor()
        if image_blob:
            c.execute("INSERT INTO work_orders (client, date, start_time, end_time, description, image) VALUES (?, ?, ?, ?, ?, ?)", 
                      (client, date, start_time, end_time, description, image_blob))
        else:
            c.execute("INSERT INTO work_orders (client, date, start_time, end_time, description) VALUES (?, ?, ?, ?, ?)", 
                      (client, date, start_time, end_time, description))
        conn.commit()

def delete_work_order(order_id):
    with sqlite3.connect('work_orders.db') as conn:
        c = conn.cursor()
        c.execute("DELETE FROM work_orders WHERE id = ?", (order_id,))
        conn.commit()

def fetch_work_orders_by_date(date=None):
    with sqlite3.connect('work_orders.db') as conn:
        c = conn.cursor()
        if date:
            c.execute("SELECT * FROM work_orders WHERE date = ?", (date,))
        else:
            c.execute("SELECT * FROM work_orders")
        return c.fetchall()

def check_time_conflict(date, start_time, end_time):
    with sqlite3.connect('work_orders.db') as conn:
        c = conn.cursor()
        c.execute("""
            SELECT * FROM work_orders 
            WHERE date = ? AND (
                (start_time <= ? AND end_time >= ?) OR
                (start_time <= ? AND end_time >= ?) OR
                (? <= start_time AND ? >= end_time)
            )
        """, (date, start_time, start_time, end_time, end_time, start_time, end_time))
        return c.fetchall()
