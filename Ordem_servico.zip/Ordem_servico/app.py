from flask import Flask, render_template, request, redirect, url_for, session, flash
from datetime import datetime, timedelta
import sqlite3
import base64
import re
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, template_folder='templates')
app.secret_key = 'secreta_chave'

@app.template_filter('b64encode')
def b64encode_filter(data):
    if isinstance(data, str):
        data = data.encode('utf-8')
    return base64.b64encode(data).decode('utf-8') if data else ''

def init_db():
    conn = sqlite3.connect('work_orders.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS work_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client TEXT NOT NULL,
            date TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT NOT NULL,
            description TEXT,
            image BLOB,
            copied INTEGER DEFAULT 0
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )
    ''')

    email = "admin@admin.com"
    password = "Admin@2025"
    password_hash = generate_password_hash(password)

    c.execute("SELECT * FROM users WHERE email = ?", (email,))
    user = c.fetchone()

    if not user:
        c.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, password_hash))
        print(f"Usuário padrão criado: {email}")
    else:
        print(f"Usuário padrão já existe: {email}")

    conn.commit()
    conn.close()

def get_user_by_email(email):
    with sqlite3.connect('work_orders.db') as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE email = ?", (email,))
        return c.fetchone()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = get_user_by_email(email)
        if user and check_password_hash(user[2], password):
            session['user'] = email
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error="Credenciais inválidas. Tente novamente.")
    return render_template('login.html')

@app.route('/')
def home():
    if 'user' not in session:
        return redirect(url_for('login'))

    with sqlite3.connect('work_orders.db') as conn:
        c = conn.cursor()
        c.execute("SELECT client, date, start_time, end_time, description, image FROM work_orders")
        work_orders = c.fetchall()
        work_orders = [
            (client, date, start_time, end_time, description.replace('\n', '<br>') if description else '', image)
            for client, date, start_time, end_time, description, image in work_orders
        ]

    total_time = calculate_hours(datetime.now().strftime('%Y-%m-%d'))
    workday_duration = timedelta(hours=9)
    remaining_time = workday_duration - total_time

    if remaining_time.total_seconds() > 0:
        hours = remaining_time.seconds // 3600
        minutes = (remaining_time.seconds % 3600) // 60
        remaining_time_formatted = f"{hours} horas e {minutes} minutos"
    else:
        remaining_time_formatted = "Carga de trabalho completa!"

    current_time = datetime.now()
    return render_template('index.html', remaining_hours=remaining_time_formatted, current_time=current_time, work_orders=work_orders)

@app.route('/add', methods=['POST'])
def add_work_order():
    client = request.form['client']
    date = request.form['date']
    start_time = request.form['start_time']
    end_time = request.form['end_time']
    description = request.form['description']

    image_data = re.findall(r'data:image/\w+;base64,([A-Za-z0-9+/=]+)', description)

    total_time = calculate_hours(date)
    workday_duration = timedelta(hours=9)
    remaining_time = workday_duration - total_time

    fmt = '%H:%M'
    try:
        os_duration = datetime.strptime(end_time, fmt) - datetime.strptime(start_time, fmt)
    except ValueError:
        flash("Formato de hora inválido. Use o formato HH:MM.", "error")
        return redirect(url_for('home'))

    if os_duration > remaining_time:
        flash("Horas de trabalho excedem o limite do dia!", "error")
        return redirect(url_for('home'))

    with sqlite3.connect('work_orders.db') as conn:
        c = conn.cursor()
        c.execute("SELECT end_time FROM work_orders WHERE date = ? ORDER BY end_time DESC LIMIT 1", (date,))
        last_end_time = c.fetchone()

        if last_end_time and last_end_time[0]:
            if start_time != last_end_time[0]:
                flash("O horário de início deve ser o mesmo que o término da última OS.", "error")
                return redirect(url_for('home'))

        c.execute("""
            SELECT * FROM work_orders 
            WHERE date = ? AND (
                (start_time < ? AND end_time > ?) OR
                (start_time < ? AND end_time > ?)
            )
        """, (date, end_time, start_time, end_time, start_time))

        conflicting_orders = c.fetchall()

        if conflicting_orders:
            flash("Conflito de horário! Já existe uma OS nesse período.", "error")
            return redirect(url_for('home'))

        if image_data:
            img_blob = base64.b64decode(image_data[0])
            c.execute("INSERT INTO work_orders (client, date, start_time, end_time, description, image) VALUES (?, ?, ?, ?, ?, ?)", (client, date, start_time, end_time, description, img_blob))
        else:
            c.execute("INSERT INTO work_orders (client, date, start_time, end_time, description) VALUES (?, ?, ?, ?, ?)", (client, date, start_time, end_time, description))

        order_id = c.lastrowid
        conn.commit()

    flash(f"OS do ID {order_id} realizada com sucesso!", "success")
    return redirect(url_for('home'))

@app.route('/relatorio', methods=['GET', 'POST'])
def relatorio():
    if 'user' not in session:
        return redirect(url_for('login'))

    selected_date = request.form.get('date') if request.method == 'POST' else datetime.now().strftime('%Y-%m-%d')

    with sqlite3.connect('work_orders.db') as conn:
        c = conn.cursor()
        c.execute("SELECT id, client, date, start_time, end_time, description, image, copied FROM work_orders WHERE date = ?", (selected_date,))
        work_orders = c.fetchall()
        work_orders = [
            (order_id, client, date, start_time, end_time, description.replace('\n', '<br>') if description else '', image, copied)
            for order_id, client, date, start_time, end_time, description, image, copied in work_orders
        ]

    return render_template('relatorio.html', work_orders=work_orders, selected_date=selected_date)

def calculate_hours(date):
    total_time = timedelta()
    with sqlite3.connect('work_orders.db') as conn:
        c = conn.cursor()
        c.execute("SELECT start_time, end_time FROM work_orders WHERE date = ?", (date,))
        rows = c.fetchall()
        for start, end in rows:
            try:
                fmt = '%H:%M'
                tdelta = datetime.strptime(end.strip(), fmt) - datetime.strptime(start.strip(), fmt)
                total_time += tdelta
            except ValueError as e:
                print(f"Erro ao analisar os horários: {e}")

    return total_time

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
